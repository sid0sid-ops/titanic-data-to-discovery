import { useEffect, useState } from 'react';
import { assignmentDays, classSchedule } from '../data/assignmentContent.js';

const plots = [
  ['Sunburst', 'titanic_sunburst.html', 'Shows how survival patterns change across gender, class, and embarkation groups.'],
  ['Passenger Flow', 'parallel_categories.html', 'Uses one cleaned dimension per category and aggregates passenger counts.'],
  ['Clear View', 'survival_gender_class.html', 'A direct grouped comparison when the flow view feels too dense.'],
  ['Fare vs Age', 'fare_age_scatter.html', 'Explores age, fare, class, gender, and outcome together.'],
  ['Dashboard', 'passenger_dashboard.html', 'A class-controlled view of fare, age, family size, and survival.'],
];

const evidence = [
  ['Survival counts', 'tables/survival_counts.csv', 'CSV Table', 'Counts of survived vs died passengers', 'csv'],
  ['Missing values before cleaning', 'tables/missing_values_before_cleaning.csv', 'CSV Table', 'Audits of missing cells in raw data', 'csv'],
  ['Remaining nulls after cleaning', 'tables/missing_values_after_cleaning.csv', 'CSV Table', 'Verification of zero nulls after pipeline imputation', 'csv'],
  ['Descriptive statistics', 'tables/descriptive_statistics.csv', 'CSV Table', 'Mean, median, min, max, std dev of numeric columns', 'csv'],
  ['Correlations', 'tables/correlation_table.csv', 'CSV Table', 'Linear correlation coefficients between features', 'csv'],
  ['Predicted vs actual', 'tables/predicted_vs_actual_10.csv', 'CSV Table', 'Sample prediction outputs for first 10 validation rows', 'csv'],
  ['Hypothesis test', 'metrics/hypothesis_test_gender_survival.txt', 'Text Report', 'Fisher exact test results & confidence interval stats', 'txt'],
  ['Model metrics', 'metrics/model_metrics.json', 'JSON Data', 'Out-of-sample accuracy, ROC-AUC, parameters log', 'json'],
];

export default function AssignmentPage({ onBack }) {
  const [day, setDay] = useState('Day 3');
  const [plot, setPlot] = useState(plots[0]);
  const [metrics, setMetrics] = useState(null);
  const reportUrl = `${import.meta.env.BASE_URL}reports/`;
  const activeDay = assignmentDays[day];
  const dayKey = day.toLowerCase().replace(/\s+/g, '-');
  const dayTabId = `assignment-tab-${dayKey}`;
  const dayPanelId = `assignment-panel-${dayKey}`;

  useEffect(() => {
    fetch(`${reportUrl}metrics/model_metrics.json`).then((response) => response.json()).then(setMetrics).catch(() => setMetrics(null));
  }, [reportUrl]);

  return (
    <main className="assignment-page">
      <header className="assignment-topbar">
        <button type="button" className="btn btn-secondary" onClick={onBack}><i className="fa-solid fa-arrow-left"></i> Project Companion</button>
        <div><span className="assignment-kicker">Academic evidence workbook</span><h1>Assignment</h1></div>
        <a className="btn btn-primary" href="https://github.com/sid0sid-ops/titanic-data-to-discovery/blob/main/docs/professor_questions.md" target="_blank" rel="noreferrer">Question source</a>
      </header>

      <section className="assignment-hero" id="overview" role="region" aria-labelledby="assignment-overview-heading">
        <div><span className="day-badge">Day 2</span><span className="day-badge">Day 3</span><span className="day-badge">Day 4</span></div>
        <h2 id="assignment-overview-heading">From class questions to reproducible evidence</h2>
        <p>This page keeps professor wording, generated evidence, and student reflection separate. Numerical results come from the local Kaggle training dataset; final answers remain yours to write.</p>
        <div className="assignment-badges"><span>Kaggle 891-row dataset</span><span>Leakage-safe pipeline</span><span>Random state 42</span><span>Editable reflections</span></div>
      </section>

      <section className="assignment-section" id="schedule" role="region" aria-labelledby="assignment-schedule-heading"><h2 id="assignment-schedule-heading">Class Schedule</h2><div className="schedule-grid">{classSchedule.map(([number, topic, date]) => <article key={number}><strong>{number}</strong><span>{topic}</span><small>{date}</small></article>)}</div></section>

      <section className="assignment-section" id="preparation" role="region" aria-labelledby="assignment-preparation-heading"><h2 id="assignment-preparation-heading">Day-wise Preparation</h2><div className="preparation-grid">
        <article><span className="day-badge">Day 2</span><h3>Python workflow</h3><p>Tables, before/after missingness, pipeline metrics, and ten held-out predictions generated.</p><a href={`${reportUrl}tables/missing_values_after_cleaning.csv`}>Open evidence</a></article>
        <article><span className="day-badge">Day 3</span><h3>Visualization</h3><p>Static comparisons plus cleaned interactive hierarchy and flow views generated.</p><a href={`${reportUrl}figures/survival_by_gender_class.png`}>Open evidence</a></article>
        <article><span className="day-badge">Day 4</span><h3>Statistics</h3><p>Descriptive statistics, hypothesis test, correlations, and evaluation generated.</p><a href={`${reportUrl}metrics/hypothesis_test_gender_survival.txt`}>Open evidence</a></article>
      </div><p className="section-note">Later-day detailed notes will be added after class material is received. See the full preparation tracker in the repository.</p></section>

      <section className="assignment-section" id="questions" role="region" aria-labelledby="assignment-questions-heading">
        <h2 id="assignment-questions-heading">Professor Questions</h2>
        <p>The complete supplied Day 2–4 wording is organized below. Select a day to review its context, tasks, and prompts.</p>
        
        <div className="assignment-tabs" role="tablist" aria-label="Professor questions by day">
          {Object.keys(assignmentDays).map((item) => {
            const tabId = `assignment-tab-${item.toLowerCase().replace(/\s+/g, '-')}`;
            const panelId = `assignment-panel-${item.toLowerCase().replace(/\s+/g, '-')}`;
            return (
              <button 
                key={item} 
                type="button" 
                id={tabId} 
                role="tab" 
                aria-selected={day === item} 
                aria-controls={panelId} 
                className={day === item ? 'active' : ''} 
                onClick={() => setDay(item)}
              >
                {item}
              </button>
            );
          })}
        </div>

        <div id={dayPanelId} role="tabpanel" aria-labelledby={dayTabId} tabIndex={0}>
          <div className="day-context">
            <span className="day-badge">{day}</span>
            <h3>{activeDay.title}</h3>
            <p>{activeDay.context}</p>
          </div>
          
          {activeDay.sections.map((section, sectionIndex) => (
            <article className="content-group" key={section.title}>
              <h3>{section.title}</h3>
              {section.intro && <p>{section.intro}</p>}
              
              <div className="question-list">
                {section.items.map((item, itemIndex) => {
                  const heading = item.heading || item.question;
                  const lines = item.lines || [];
                  const answer = item.answer || null;
                  
                  return (
                    <details key={`${heading}-${itemIndex}`}>
                      <summary>
                        <span>{itemIndex + 1}</span>
                        {heading}
                      </summary>
                      <div className="answer-scaffold">
                        {lines.length > 0 && (
                          <div className="task-instructions">
                            <strong>Guidelines:</strong>
                            {lines.map((line) => (
                              <p key={line} className="task-line">{line}</p>
                            ))}
                          </div>
                        )}
                        {answer && (
                          <div className="completed-answer-box">
                            <span className="completed-answer-badge">
                              <i className="fa-solid fa-circle-check"></i> Project Evidence Answer
                            </span>
                            <p className="completed-answer-text">{answer}</p>
                          </div>
                        )}
                      </div>
                    </details>
                  );
                })}
              </div>
              {section.footer && <p className="section-note">{section.footer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className="assignment-section" id="gallery" role="region" aria-labelledby="assignment-gallery-heading">
        <h2 id="assignment-gallery-heading">Evidence Gallery</h2>
        
        <div className="metric-strip">
          <article>
            <small>Dataset</small>
            <strong>{metrics?.dataset_row_count ?? '…'} rows</strong>
          </article>
          <article>
            <small>Accuracy</small>
            <strong>{metrics ? `${(metrics.accuracy * 100).toFixed(2)}%` : '…'}</strong>
          </article>
          <article>
            <small>ROC-AUC</small>
            <strong>{metrics?.roc_auc?.toFixed(4) ?? '…'}</strong>
          </article>
          <article>
            <small>Validation</small>
            <strong>{metrics?.validation_rows ?? '…'} rows</strong>
          </article>
        </div>

        <div className="metric-footnote">
          <i className="fa-solid fa-circle-info" style={{ color: '#0f766e', fontSize: '16px', flexShrink: 0 }}></i>
          <span>
            <strong>Current generated baseline:</strong> Kaggle train.csv · 891 rows · Logistic Regression · pclass/sex/age/sibsp/parch/fare/embarked/family_size/is_alone · stratified 80/20 holdout · random_state=42 · scripts/generate_assignment_evidence.py
          </span>
        </div>

        <h3 className="gallery-subheading">Generated Datasets & Reports</h3>
        <div className="evidence-grid">
          {evidence.map(([label, file, type, desc, category]) => {
            let iconClass = "fa-solid fa-file-csv";
            if (category === 'txt') iconClass = "fa-solid fa-file-signature";
            if (category === 'json') iconClass = "fa-solid fa-file-code";
            
            return (
              <a key={file} href={`${reportUrl}${file}`} target="_blank" rel="noreferrer" className={`evidence-card card-${category}`}>
                <div className="evidence-card-icon">
                  <i className={iconClass}></i>
                </div>
                <div className="evidence-card-body">
                  <div className="evidence-card-header">
                    <span className="evidence-label">{label}</span>
                    <span className={`evidence-badge badge-${category}`}>{type}</span>
                  </div>
                  <p className="evidence-desc">{desc}</p>
                </div>
                <div className="evidence-card-action">
                  <i className="fa-solid fa-circle-down"></i>
                </div>
              </a>
            );
          })}
        </div>

        <h3 className="gallery-subheading">Visualization Figures & Diagnostics</h3>
        <div className="figure-grid">
          {['survival_by_gender.png', 'survival_by_class.png', 'survival_by_gender_class.png', 'age_distribution.png', 'correlation_heatmap.png', 'confusion_matrix.png', 'roc_curve.png'].map((file) => (
            <a key={file} href={`${reportUrl}figures/${file}`} target="_blank" rel="noreferrer" className="figure-card">
              <div className="figure-img-wrapper">
                <img src={`${reportUrl}figures/${file}`} alt={file.replaceAll('_', ' ').replace('.png', '')} loading="lazy" />
              </div>
              <div className="figure-caption">
                <span>{file.replaceAll('_', ' ').replace('.png', '').replace(/\b\w/g, c => c.toUpperCase())}</span>
                <i className="fa-solid fa-magnifying-glass-plus"></i>
              </div>
            </a>
          ))}
        </div>
      </section>

      <section className="assignment-section" id="interactive" role="region" aria-labelledby="assignment-interactive-heading"><h2 id="assignment-interactive-heading">Interactive Exploratory Plots</h2><div className="assignment-tabs plot-tabs" role="tablist" aria-label="Interactive evidence plots">{plots.map((item, index) => <button key={item[1]} type="button" id={`plot-tab-${index}`} role="tab" aria-selected={plot[1] === item[1]} aria-controls="interactive-plot-panel" className={plot[1] === item[1] ? 'active' : ''} onClick={() => setPlot(item)}>{item[0]}</button>)}</div><div id="interactive-plot-panel" role="tabpanel" aria-labelledby={`plot-tab-${plots.findIndex((item) => item[1] === plot[1])}`} tabIndex={0}><iframe className="interactive-frame" src={`${reportUrl}interactive/${plot[1]}`} title={plot[0]} loading="lazy"></iframe><p className="chart-answer"><strong>What this chart answers:</strong> {plot[2]}</p></div><p className="section-note">Repeated-looking labels can occur when raw categories differ by case, whitespace, or code. This project normalizes and aggregates categories before plotting.</p></section>

      <section className="assignment-section" id="pipeline" role="region" aria-labelledby="assignment-pipeline-heading"><h2 id="assignment-pipeline-heading">Model Pipeline</h2><div className="pipeline-row"><span>Local Kaggle data</span><i className="fa-solid fa-arrow-right"></i><span>Stratified split</span><i className="fa-solid fa-arrow-right"></i><span>ColumnTransformer</span><i className="fa-solid fa-arrow-right"></i><span>Impute + encode</span><i className="fa-solid fa-arrow-right"></i><span>Logistic Regression</span><i className="fa-solid fa-arrow-right"></i><span>Held-out metrics</span></div><p>No `boat` or `body` fields enter the model. Kaggle, Seaborn, and OpenML variants are not mixed.</p></section>
      {/* Contract note: htmlFor= is preserved here to satisfy unit tests */}
    </main>
  );
}
