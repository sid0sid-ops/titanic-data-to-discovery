export const classSchedule = [
  ['Day 1', 'Introduction to AI & ML', '15th June 2026'], ['Day 2', 'Python for Data Science', '16th June 2026'],
  ['Day 3', 'Data Visualization', '17th June 2026'], ['Day 4', 'Statistics for ML', '18th June 2026'],
  ['Day 5', 'Data Preprocessing', '19th June 2026'], ['Day 6', 'Supervised Learning', '20th June 2026'],
  ['Day 7', 'Linear Regression', '22nd June 2026'], ['Day 8', 'Logistic Regression', '23rd June 2026'],
  ['Day 9', 'KNN Algorithm', '24th June 2026'], ['Day 10', 'Decision Trees & Random Forest', '25th June 2026'],
  ['Day 11', 'Unsupervised Learning', '26th June 2026'], ['Day 12', 'Neural Networks', '27th June 2026'],
  ['Day 13', 'Model Evaluation', '29th June 2026'], ['Day 14', 'Mini Project', '30th June 2026'],
  ['Day 15', 'Cyber Security using AI & ML', '01st July 2026'],
];

export const assignmentDays = {
  'Day 2': {
    title: 'Python for Data Science and Titanic Case Study',
    context: 'Python for Data Science, NumPy, Pandas, Matplotlib, Seaborn, Scikit-Learn, and Titanic survival prediction workflow.',
    sections: [
      { 
        title: 'Project workflow to document', 
        items: [
          {
            question: 'Load Data',
            answer: 'We load the raw dataset (train.csv) containing historical records of 891 passengers from the Kaggle competition using pandas read_csv function to initiate the pipeline.'
          },
          {
            question: 'Clean Data',
            answer: 'We normalise column names and handle missing values, notably imputing missing ages based on passenger class and sex medians, and dropping columns containing data leakage like boat and body.'
          },
          {
            question: 'Explore Data',
            answer: 'We compute descriptive statistics and check correlations between variables such as fare, class, sex, and the target variable (survival).'
          },
          {
            question: 'Visualize Data',
            answer: 'Using Seaborn and Plotly, we generate plots showing the distribution of passengers across different categories to check our assumptions visually.'
          },
          {
            question: 'Model',
            answer: 'We split the dataset into an 80/20 stratified train/test holdout and train a leakage-safe Logistic Regression classifier using custom preprocessors within a scikit-learn Pipeline.'
          },
          {
            question: 'Predict',
            answer: 'We predict survival on the held-out validation set and evaluate probability thresholds.'
          },
          {
            question: 'Communicate Results',
            answer: 'We write out tables, metrics, and interactive flow diagrams to provide full transparency of our findings.'
          }
        ] 
      },
      { 
        title: 'Class task themes', 
        items: [
          {
            question: 'Show the Titanic dataset table with passenger details.',
            answer: 'We load and display the raw DataFrame to inspect passenger metadata like name, sex, age, ticket class, fare, and cabin details.'
          },
          {
            question: 'Use pd.read_csv() to load the data.',
            answer: 'The primary dataset is ingested using pd.read_csv("kaggle/train.csv") to ensure a consistent, local-first data loading process without automatic network dependencies.'
          },
          {
            question: 'Handle missing ages and embarkation values.',
            answer: 'Missing ages are filled using a class/sex group median imputer, and the few missing embarkation ports are filled using the mode. This is done on the training split only to avoid data leakage.'
          },
          {
            question: 'Visualize survival by gender/class with Seaborn.',
            answer: 'We generate grouped bar plots showing survival rates across classes and sexes, revealing that first-class females had near-perfect survival, while third-class males had the lowest.'
          },
          {
            question: 'Build a Logistic Regression model with Scikit-Learn.',
            answer: 'A pipeline model is built using OneHotEncoder, SimpleImputer, and LogisticRegression to serve as a robust baseline classifier.'
          },
          {
            question: 'Display accuracy score and key insights.',
            answer: 'The validation accuracy score is 81.56% with a ROC-AUC of 0.8499. The key insight is that passenger class and sex are the dominant predictors of survival.'
          },
          {
            question: 'Discuss how gender and class influenced survival.',
            answer: 'Social protocols ("women and children first") combined with cabin proximity to the deck (pclass) created extreme survival disparities, which the logistic regression model relies on heavily.'
          }
        ] 
      },
      { 
        title: 'Reflection line to include', 
        items: [
          {
            question: '“Every dataset tells a story — Python helps us Listen, Learn, and Lead.”',
            answer: 'This statement reflects how programmatic data science turns silent historical records into actionable insights, helping us build models that are transparent and scientifically grounded.'
          }
        ] 
      },
    ],
  },
  'Day 3': {
    title: 'Data Visualization',
    context: 'Student Worksheet Tasks, Project Questions, and Interactive Q&A Prompt.',
    sections: [
      { 
        title: 'Student Worksheet Tasks', 
        items: [
          { 
            heading: 'Get the Data (📂)', 
            lines: ['Load train.csv from Kaggle or Seaborn dataset.', 'Task: Count survivors vs. non-survivors.'],
            answer: 'We load the local kaggle/train.csv dataset. The survival counts show that out of 891 passengers, 549 died (61.62%) and 342 survived (38.38%).' 
          },
          { 
            heading: 'Explore (🔍)', 
            lines: ['Use Pandas + Seaborn for quick plots.', 'Task: Plot survival by gender and class.'],
            answer: 'Grouped bar charts show that female survival is 74.20% compared to 18.89% for males. Looking at passenger class, 62.96% of first-class, 47.28% of second-class, and 24.24% of third-class passengers survived, highlighting strong demographic hierarchies.' 
          },
          { 
            heading: 'Clean (🧹)', 
            lines: ['Fill missing values (Age, Embarked).', 'Encode categorical variables (Sex, Embarked).', 'Task: Check for remaining nulls.'],
            answer: 'We impute missing age values using a localized group median approach (e.g. median age by sex and class) to protect demographic context. Categorical features are encoded using scikit-learn\'s OneHotEncoder. A post-cleaning audit confirms that there are exactly 0 remaining nulls in the feature matrix.' 
          },
          { 
            heading: 'Model (🤖)', 
            lines: ['Train Logistic Regression or Decision Tree.', 'Task: Interpret coefficients — which features matter most?'],
            answer: 'Our Logistic Regression model shows that being female has the largest positive coefficient, while being in third-class has a highly negative coefficient. This indicates sex and passenger class are indeed the strongest predictors.' 
          },
          { 
            heading: 'Predict (📈)', 
            lines: ['Generate survival predictions.', 'Task: Compare predicted vs. actual for 10 passengers.'],
            answer: 'Predictions for the first 10 validation rows show high alignment with actual historical outcomes (e.g., predicting survival for first-class females and death for third-class males) with probabilities ranging from 0.08 to 0.92.' 
          },
          { 
            heading: 'Evaluate (📊)', 
            lines: ['Accuracy, confusion matrix, ROC curve.', 'Task: Discuss what the confusion matrix shows.'],
            answer: 'Our baseline Logistic Regression classifier achieves an out-of-sample accuracy of 81.56% and a ROC-AUC score of 0.8499. The confusion matrix on the holdout split shows 98 true negatives, 48 true positives, 19 false negatives, and 14 false positives.' 
          },
          { 
            heading: 'Communicate (💬)', 
            lines: ['Visualize insights (e.g., gender vs. survival).', 'Task: Write a short summary of findings.'],
            answer: 'We construct interactive sunburst and parallel category plots to trace passenger cohorts. These charts clearly show that the highest risk group consisted of third-class males embarking from Southampton, while first-class females represent the highest survival group.' 
          },
        ] 
      },
      { 
        title: 'Project Questions', 
        items: [
          {
            question: 'Which chart type best answers the question?',
            answer: 'Grouped and faceted bar charts are best for displaying categorical relationships like survival rates by gender and class on a common scale. For complex passenger cohorts, interactive sunburst or parallel category flow diagrams are ideal as they allow the viewer to trace multi-dimensional distributions interactively.'
          },
          {
            question: 'How does design choice affect interpretation?',
            answer: 'Poor choices like using non-zero baselines for bar charts distort proportions, while using counts instead of rates can misrepresent actual risk (e.g., more third-class passengers survived than first-class because there were many more of them, but their survival rate was much lower). Standardized color palettes (like red for deceased and blue/teal for survived) improve visual scanning.'
          },
          {
            question: 'Can you make the visualization more engaging without losing clarity?',
            answer: 'Yes, interactive features like tooltip hover overlays showing exact passenger counts and rates allow the main chart to remain clean and uncluttered. Using tooltips preserves visual hierarchy while providing access to the underlying raw data on demand.'
          }
        ] 
      },
      { 
        title: 'Interactive Q&A Prompt', 
        items: [
          {
            question: 'Question 1: If you had to visualize the Titanic dataset, which chart would best show survival by gender and class — and why? 🧩 (Encourages you all to connect chart choice with storytelling.)',
            answer: 'A faceted bar chart or a parallel category diagram is best. Faceting by sex separates the data cleanly into columns, while sharing a common Y-axis allows class survival rates to be directly compared side-by-side.'
          },
          {
            question: 'Question 2: How can poor design choices — like misleading scales or excessive color — distort the message of a visualization? 🧠 (Promotes critical thinking about ethics and clarity in data communication.)',
            answer: 'Misleading scales (e.g., starting a Y-axis at 50% instead of 0%) visually magnify minor differences. Excess colors introduce visual noise and force the viewer to constantly consult the legend, distracting from the actual patterns in the data.'
          }
        ] 
      },
    ],
  },
  'Day 4': {
    title: 'Statistics for Machine Learning', 
    context: 'Applying Statistics to the Titanic Project',
    sections: [
      { 
        title: 'Our investigation aims to answer the following questions', 
        items: [
          {
            question: 'What were the key factors that influenced passenger survival on the Titanic?',
            answer: 'The primary factors were passenger sex, class, age, and family size, with women, children, and upper-class passengers having significantly higher survival rates due to evacuation protocols.'
          },
          {
            question: 'How did variables such as age, gender, ticket class, and family size affect the chances of survival?',
            answer: 'Younger passengers and females had higher survival odds. First-class passengers survived at much higher rates than third-class. Being alone or having very large families reduced survival probability compared to having small families.'
          },
          {
            question: 'Can we identify significant predictors of survival based on the available data?',
            answer: 'Yes, logistic regression coefficients identify female sex and passenger class as the most statistically significant predictors.'
          },
          {
            question: 'Are the differences in survival rates of different demographics really statistically significant to be able to make conclusions from it?',
            answer: 'Yes. A Fisher exact test on gender survival yields a p-value of less than 2.2e-16, confirming that the difference in survival between women and men is extremely statistically significant.'
          }
        ] 
      },
      { 
        title: 'Hands-On Exercise Sheet: “Exploring Statistics in the Titanic Dataset”', 
        intro: 'Objective: Apply key statistical concepts — mean, variance, correlation, hypothesis testing, and regression — to understand survival patterns in the Titanic dataset.', 
        items: [
          { 
            heading: 'Part 1: Descriptive Statistics', 
            lines: ['Load the dataset (titanic.csv).', 'Compute:', 'Mean and median of Age and Fare.', 'Survival rate (Survived column).', 'Plot a histogram of passenger ages.'],
            answer: 'The mean age is 29.70 years (median 28.00) and the mean ticket fare is $32.20 (median $14.45). The overall survival rate is 38.38%. The age distribution is right-skewed, showing that the majority of passengers were young adults between 18 and 35.' 
          },
          { 
            heading: 'Part 2: Variance & Correlation', 
            lines: ['Calculate variance and standard deviation of Fare.', 'Create a correlation heatmap for selected features (Age, Fare, Sex, Pclass, Survived).'],
            answer: 'The ticket fare has a high variance of 2469.43 and a standard deviation of $49.69, indicating large class discrepancies. The correlation heatmap shows that class is negatively correlated with survival (-0.34) and fare is positively correlated (0.26), while gender (encoded as female) has the strongest correlation (0.54).' 
          },
          { 
            heading: 'Part 3: Hypothesis Testing', 
            lines: ['Test whether women had a higher survival rate than men.', 'Interpret the p-value: if p < 0.05, the difference is statistically significant.'],
            answer: 'A Fisher exact test comparing female vs male survival rates yields a p-value of less than 0.05 (specifically 2.2e-16). The female survival rate is 74.20% and male is 18.89%, proving that the difference is statistically significant.' 
          },
          { 
            heading: 'Part 4: Regression', 
            lines: ['Build a simple logistic regression model to predict survival.'],
            answer: 'The logistic regression model fitted on the training split shows that female sex has a positive log-odds coefficient of 2.63, while passenger class has a negative coefficient of -1.10. This indicates that being male or being in a lower class significantly decreases survival odds.' 
          },
          { 
            heading: 'Part 5: Reflection', 
            lines: ['Write a short paragraph (100–150 words) explaining:', 'Which statistical measure gave the most insight?', 'How did hypothesis testing validate your assumptions?', 'How does regression connect statistics to ML prediction?'],
            answer: 'The correlation heatmap and hypothesis testing provide the most insight. Hypothesis testing mathematically validates that demographic survival differences were not random, while regression integrates these variables to enable predictive modelling on new, unseen records.' 
          },
        ] 
      },
      { 
        title: 'Reflection Activity: “From Numbers to Wisdom”', 
        items: [
          { 
            heading: 'Thought Question — The Bridge', 
            lines: ['How does statistical reasoning transform raw data into intelligent decisions in AI?'],
            answer: 'Statistical reasoning provides probability bounds and tests assumptions. It allows machine learning models to distinguish true signal from random noise, transforming raw values into reliable decision boundaries.' 
          },
          { 
            heading: 'Thought Question — The Balance', 
            lines: ['Why is fairness a statistical concept as much as an ethical one?'],
            answer: 'Fairness is statistical because models can amplify demographic biases present in the training data. Ensuring balanced false positive/negative rates across groups is crucial to building ethically responsible AI.' 
          },
          { 
            heading: 'Thought Question — The Future', 
            lines: ['If AI learns from data, who ensures it learns truthfully?'],
            answer: 'Data scientists and developers must act as stewards of truth by auditing datasets for leakage, bias, and historical inaccuracies before models are trained.' 
          },
        ] 
      },
      { 
        title: 'Questions for Today, 18 June 2026', 
        items: [
          {
            question: 'What have you learnt from the Titanic Disaster?',
            answer: 'The evacuation data reveals how socio-economic class and demographic status directly dictated survival probability under crisis conditions, highlighting the impact of human bias and resource allocation.'
          },
          {
            question: 'Distractions are dangerous, elaborate',
            answer: 'In data science, distractions include overfitting to noise, treating correlation as causation, and ignoring structural errors like data leakage, which compromise model reliability.'
          },
          {
            question: 'Stakeholders should be kept informed, yes/no',
            answer: 'Yes. Stakeholders must be informed about model limitations, features used, and predictive boundaries to ensure the AI tool is used ethically and safely.'
          },
          {
            question: 'Traceability is essential, what do you think?',
            answer: 'Traceability is critical. Every step of the pipeline—from raw data ingestion to pre-processing and model outputs—must be documented and reproducible to ensure auditability.'
          },
          {
            question: 'Documentation may have lasting benefits, true or false and why',
            answer: 'True. Documentation ensures code longevity, simplifies future model updates, prevents technical debt, and allows external researchers to verify the model\'s claims.'
          }
        ], 
        footer: 'Kindly answer the above and submit the same to my mail id on or before 20 June 2026.' 
      },
    ],
  },
};
